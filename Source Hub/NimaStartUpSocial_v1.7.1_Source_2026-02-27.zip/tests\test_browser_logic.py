import unittest
from unittest.mock import patch
from logic.browser_service import BrowserService

class TestBrowserLogic(unittest.TestCase):
    @patch('os.path.exists')
    def test_detection_logic(self, mock_exists):
        # Simulate Chrome exists, Edge doesn't
        mock_exists.side_effect = lambda path: "chrome.exe" in path.lower()
        browsers = BrowserService.detect_browsers()
        
        # Check if chrome is in list and edge is marked missing or not present
        # This depends on exact implementation of detect_browsers
        chrome_present = any("chrome" in b['id'] for b in browsers if b['available'])
        self.assertTrue(chrome_present)

    def test_get_command_default(self):
        cmd = BrowserService.get_browser_command("default", "https://test.com")
        # Should be just the URL or start with start/open
        self.assertIn("https://test.com", cmd)

if __name__ == "__main__":
    unittest.main()
