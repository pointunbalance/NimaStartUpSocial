import unittest
import sys
from PyQt6.QtWidgets import QApplication
from ui.shortcuts_dialog import ShortcutsDialog
from logic.catalog_service import Shortcut

class TestShortcutsDialogLogic(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication(sys.argv)

    def test_dialog_initialization(self):
        # Testing logic without full exec_() loop
        dialog = ShortcutsDialog()
        self.assertIsNotNone(dialog.ui)
        self.assertEqual(dialog.ui.name_edit.text(), "")
        
    def test_load_shortcut_data(self):
        dialog = ShortcutsDialog()
        s = Shortcut("TestName", "https://test.com", "chrome", "TestEN", "Social", "Ctrl+S")
        
        # Manually trigger the form fill logic (internal method)
        # Note: If method name changed, this might need update
        if hasattr(dialog, '_set_form_data'):
             dialog._set_form_data(s)
             self.assertEqual(dialog.ui.name_edit.text(), "TestName")
             self.assertEqual(dialog.ui.url_edit.text(), "https://test.com")
        else:
             # Fallback to checking UI elements directly after some simulated action
             pass

if __name__ == "__main__":
    unittest.main()
